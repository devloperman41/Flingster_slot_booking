const API_URL = "https://slotbooking--imadi0007.replit.app/api/access/validate";
const FLINGSTER_URL = "https://flingster.com";

const codeInput = document.getElementById("access-code");
const validateButton = document.getElementById("validate");
const clearButton = document.getElementById("clear");
const message = document.getElementById("message");
const active = document.getElementById("active");

function showMessage(text, type = "") {
  message.textContent = text;
  message.className = `message ${type}`;
}

function showActive(result) {
  const remaining = Math.max(0, result.remainingSeconds || 0);
  const minutes = Math.floor(remaining / 60);
  const seconds = String(remaining % 60).padStart(2, "0");
  active.hidden = false;
  active.innerHTML = `<strong>${minutes}:${seconds}</strong>Access verified for ${result.slotDate} · ${result.slotTime}.`;
}

async function validate() {
  const accessCode = codeInput.value.trim();
  if (accessCode.length !== 12) {
    showMessage("Enter your 12-character access code.", "error");
    return;
  }

  validateButton.disabled = true;
  active.hidden = true;
  showMessage("Checking your booking…");
  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ accessCode }),
    });
    const result = await response.json();
    if (!response.ok || !result.authorized) {
      const errors = {
        Invalid: "That access code is not valid.",
        NotStarted: "This booking has not started yet.",
        Expired: "This access period has ended.",
      };
      showMessage(errors[result.status] || "Access could not be verified.", "error");
      return;
    }

    await chrome.storage.local.set({ accessCode });
    showMessage("Access verified. Opening the official site…", "success");
    showActive(result);
    await chrome.tabs.create({ url: FLINGSTER_URL });
  } catch {
    showMessage("Could not reach the access service. Check your connection and try again.", "error");
  } finally {
    validateButton.disabled = false;
  }
}

validateButton.addEventListener("click", validate);
codeInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") validate();
});
codeInput.addEventListener("input", () => {
  codeInput.value = codeInput.value.replace(/\s/g, "");
});
clearButton.addEventListener("click", async () => {
  await chrome.storage.local.remove("accessCode");
  codeInput.value = "";
  active.hidden = true;
  showMessage("Saved code cleared.", "success");
});

chrome.storage.local.get("accessCode").then(({ accessCode }) => {
  if (accessCode) codeInput.value = accessCode;
});