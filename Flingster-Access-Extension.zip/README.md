# Flingbook Access extension

This is a Manifest V3 Chrome extension companion for the Flingbook booking website.

## Install locally

1. Open `chrome://extensions`.
2. Turn on Developer mode.
3. Click **Load unpacked**.
4. Select this directory.
5. Pin **Flingbook Access** from the extensions menu.

## User flow

1. Book a slot on the Flingbook website.
2. Copy the 12-character access code.
3. Open the extension.
4. Enter the code and select **Access Flingster**.
5. The extension validates the booking window and opens the official Flingster site.

The extension intentionally does not request, store, or inject third-party credentials or cookies. The server response contains booking authorization and timing only.